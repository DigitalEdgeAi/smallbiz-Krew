import React from 'react';

export type AIModelType = 'local_echo' | 'custom_api'; // Add more types as needed

export interface AIWorker {
  id: string;
  name: string;
  description: string;
  avatar?: string; // Optional: path to an avatar image
  modelType: AIModelType;
  apiEndpoint?: string; // Optional: for 'custom_api' type
  apiKey?: string; // Optional: for 'custom_api' type, user-provided
}

interface AIWorkerSelectorProps {
  workers: AIWorker[];
  selectedWorkerId: string | null;
  onSelectWorker: (workerId: string) => void;
}

const AIWorkerSelector: React.FC<AIWorkerSelectorProps> = ({ workers, selectedWorkerId, onSelectWorker }) => {
  return (
    <div className="w-64 bg-slate-900 p-4 space-y-2 h-full text-white fixed top-0 left-0 pt-16 overflow-y-auto">
      <h3 className="text-lg font-semibold mb-3 text-sky-400">Choose an AI Worker</h3>
      {workers.map((worker) => (
        <button
          key={worker.id}
          onClick={() => onSelectWorker(worker.id)}
          className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors duration-150
            ${selectedWorkerId === worker.id 
              ? 'bg-sky-600 text-white font-semibold'
              : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
            }
          `}
        >
          {worker.name}
          <p className="text-xs text-slate-400">({worker.modelType})</p>
        </button>
      ))}
    </div>
  );
};

export default AIWorkerSelector;

