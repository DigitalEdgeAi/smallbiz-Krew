## SmallBizCrew System Architecture

### 1. Introduction

This document outlines the system architecture for SmallBizCrew, a workflow management platform for small businesses. The platform will include project management, team communication, marketing tools, and a dedicated interface for interacting with AI workers. The design prioritizes the use of free-tier services and a modular approach for future scalability, as requested by the user and detailed in the provided requirements.

### 2. Overall Architecture

The system will adopt a client-server architecture:

*   **Frontend (Client-side):** A Single Page Application (SPA) built with React.js, responsible for the user interface and user experience.
*   **Backend (Server-side):** Leveraging Backend-as-a-Service (BaaS) platforms like Firebase or Supabase to handle data storage, authentication, real-time communication, and other backend logic.
*   **AI Worker Integration:** A dedicated module will manage interactions with AI workers. Initially, this might involve pre-defined AI personas or simple rule-based AI. For more advanced capabilities, it can be designed to integrate with external AI APIs if available and within the free-tier constraints.

### 3. Frontend Architecture

*   **Framework:** React.js
*   **UI Components:** Material UI or Chakra UI (free component libraries) for pre-built, customizable UI elements.
*   **Styling:** Tailwind CSS for utility-first CSS styling, enabling rapid development of a responsive and modern interface.
*   **State Management:** React Context API for simpler state management, or Redux/Zustand for more complex state if needed as the application grows.
*   **Routing:** React Router for client-side navigation.
*   **Key Modules/Views:**
    *   Dashboard/Homepage
    *   Project Management Board (Kanban view)
    *   Team Chat Interface (channels, direct messages)
    *   AI Worker Chat Interface (worker selection, chat history)
    *   Marketing Tools (content calendar, post scheduler)
    *   User Authentication (login, registration, profile)
    *   Settings

### 4. Backend Architecture

Firebase (or Supabase as an alternative) will be the primary backend solution, utilizing its free tier.

*   **Authentication:** Firebase Authentication (or Supabase Auth) for user sign-up, login, and session management.
*   **Database:**
    *   Firebase Realtime Database or Firestore (or Supabase PostgreSQL) for storing application data.
    *   **Data Models (Collections/Tables):**
        *   `users`: User profiles, authentication details.
        *   `projects`: Project details, members.
        *   `tasks`: Task details (title, description, assignee, due date, status, comments, sub-tasks).
        *   `team_chats`: Messages for team communication (sender, receiver/channel, content, timestamp, attachments).
        *   `ai_workers`: Profiles for different AI workers (name, description, capabilities/specialization, avatar).
        *   `ai_worker_chats`: Saved chat conversations with AI workers (user_id, worker_id, message_log, timestamp).
        *   `marketing_calendar`: Scheduled posts, content drafts.
*   **Storage:** Firebase Cloud Storage (or Supabase Storage) for file uploads (e.g., task attachments, chat files, marketing assets).
*   **Real-time Communication:** Firebase Realtime Database for the team chat and potentially for live updates in the AI worker chat interface.
*   **Serverless Functions (Optional, if needed):** Firebase Cloud Functions (or Supabase Edge Functions) for custom backend logic that cannot be handled client-side or directly by BaaS features (e.g., interacting with third-party APIs for AI workers if that route is chosen, complex data processing).

### 5. AI Worker Module Design

This module is a key addition based on the user's request.

*   **AI Worker Profiles:** Stored in the database (`ai_workers` collection). Each profile will define the AI worker's persona, such as "Marketing Assistant AI," "Customer Support Bot," "Research Analyst AI." Initially, these can be simple descriptions.
*   **Selection Interface:** Users will be able to browse and select an AI worker to interact with from a list or grid view.
*   **Chat Interface:** A dedicated chat UI, similar to the team chat but tailored for AI interaction. It will display the conversation history with the selected AI worker.
*   **Interaction Logic:**
    *   **Initial Implementation:** The "AI" responses could be pre-programmed based on keywords, or follow simple decision trees. This allows for a functional prototype without external AI dependencies.
    *   **Future Enhancement:** Integrate with a generic LLM API (e.g., a free tier of a commercial LLM if available and compliant, or an open-source model hosted on a free platform if feasible). The backend (possibly via a Cloud Function) would mediate these API calls.
*   **Chat Saving:** All conversations with AI workers will be saved to the `ai_worker_chats` collection in the database, associated with the user and the specific AI worker. This allows users to resume conversations or review past interactions.

### 6. Other Core Modules (as per attachment)

*   **Project Management Board:**
    *   Kanban-style board (To Do, In Progress, Done columns).
    *   Task creation, assignment, due dates, descriptions, comments.
    *   Data stored in `projects` and `tasks` collections.
*   **Team Chat Interface:**
    *   Real-time messaging using Firebase Realtime Database.
    *   Channels and direct messaging capabilities.
    *   File sharing (links to files in Firebase Storage).
    *   Data stored in `team_chats` collection.
*   **Marketing Tools:**
    *   Content calendar for scheduling social media posts.
    *   Draft storage for posts.
    *   Basic integration with social media APIs (Facebook, Twitter - leveraging free tiers where possible).
    *   Data stored in `marketing_calendar` collection.

### 7. API Design (Conceptual)

While much of the interaction will be directly with the BaaS, if serverless functions are used, example endpoints might include:

*   `POST /api/ai-chat/{workerId}/message`: Send a message to an AI worker.
*   `GET /api/ai-chat/{workerId}/history`: Retrieve chat history with an AI worker.
*   `POST /api/schedule-post`: Schedule a marketing post (if involving complex logic beyond client-side capabilities).

### 8. Deployment

*   **Frontend:** Vercel or Netlify (free tier) for continuous deployment from a Git repository.
*   **Backend:** Firebase or Supabase (inherently cloud-hosted).

### 9. Technology Stack Summary

*   **Frontend:** React.js, Material UI/Chakra UI, Tailwind CSS
*   **Backend:** Firebase (Authentication, Realtime Database/Firestore, Cloud Storage, Cloud Functions) or Supabase (Auth, PostgreSQL, Storage, Edge Functions)
*   **AI Integration (Initial):** Rule-based or pre-programmed responses.
*   **AI Integration (Future):** Potential integration with external LLM APIs via Cloud Functions.

### 10. Scalability and Modularity

The use of a BaaS backend provides inherent scalability for many operations. The frontend will be built with modular components. The AI worker module will be designed to be extensible, allowing for different types of AI or more sophisticated integrations in the future.

This architecture provides a solid foundation for developing SmallBizCrew, incorporating the user's specific request for an AI worker chat interface alongside the features detailed in the initial attachment.
