import React, { useState, useCallback } from 'react';
import './App.css';
import AIChatInterface, { Message } from './components/AIChatInterface';
import AIWorkerSelector, { AIWorker, AIModelType } from './components/AIWorkerSelector';

// Mock data for AI Workers with multi-model support
const mockWorkers: AIWorker[] = [
  {
    id: 'worker-1',
    name: 'Marketing Assistant (Echo)',
    description: 'Helps with marketing tasks (local echo).',
    modelType: 'local_echo',
  },
  {
    id: 'worker-2',
    name: 'Support Bot (Echo)',
    description: 'Provides customer support (local echo).',
    modelType: 'local_echo',
  },
  {
    id: 'worker-3',
    name: 'Research Analyst (Echo)',
    description: 'Gathers and analyzes information (local echo).',
    modelType: 'local_echo',
  },
  {
    id: 'worker-4',
    name: 'My Custom API Worker',
    description: 'Connects to a user-defined API.',
    modelType: 'custom_api',
    // Users would configure these, perhaps via a settings UI in a real app
    // For this prototype, we can hardcode a placeholder or a test echo API if available
    // Example using a public echo API (Postman Echo)
    apiEndpoint: 'https://postman-echo.com/post', 
    apiKey: '', // No API key needed for Postman Echo post endpoint
  },
  {
    id: 'worker-5',
    name: 'Creative Writer (Echo)',
    description: 'Assists with content creation (local echo).',
    modelType: 'local_echo',
  }
];

// In-memory store for chat histories (workerId -> messages[])
const chatHistories: Record<string, Message[]> = {};

function App() {
  const [selectedWorkerId, setSelectedWorkerId] = useState<string | null>(mockWorkers[0]?.id || null); // Select first worker by default

  const handleSelectWorker = (workerId: string) => {
    setSelectedWorkerId(workerId);
  };

  const getChatHistoryForWorker = useCallback((workerId: string): Message[] => {
    return chatHistories[workerId] || [];
  }, []);

  const saveMessageToWorkerHistory = useCallback((workerId: string, message: Message) => {
    if (!chatHistories[workerId]) {
      chatHistories[workerId] = [];
    }
    chatHistories[workerId].push(message);
  }, []);

  const currentSelectedWorker = mockWorkers.find(w => w.id === selectedWorkerId) || null;

  return (
    <div className="flex h-screen bg-slate-950 text-white overflow-hidden">
      <AIWorkerSelector 
        workers={mockWorkers} 
        selectedWorkerId={selectedWorkerId}
        onSelectWorker={handleSelectWorker} 
      />
      {/* The main content area needs to be aware of the sidebar's width */}
      {/* The AIChatInterface itself will fill its container */}
      <main className="flex-grow pl-64"> {/* pl-64 matches sidebar width */}
        <AIChatInterface 
          currentWorker={currentSelectedWorker}
          getChatHistory={getChatHistoryForWorker}
          saveMessageToHistory={saveMessageToWorkerHistory}
        />
      </main>
    </div>
  );
}

export default App;

