import React from 'react';

const SettingsPage: React.FC = () => {
  return (
    <div className="p-6 bg-slate-900 min-h-screen text-white">
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-sky-400">Settings</h1>
      </header>
      <div className="bg-slate-800 p-6 rounded-lg shadow">
        <h2 className="text-xl font-semibold text-white mb-2">Application Settings</h2>
        <p className="text-slate-300">User preferences, API key management for AI Workers, and other application settings will be available here.</p>
        <div className="mt-4">
          <h3 className="text-lg font-semibold text-white mb-2">AI Worker API Keys (Example)</h3>
          <div className="mb-2">
            <label htmlFor="customApiKey" className="block text-sm font-medium text-slate-300 mb-1">Your Custom API Key:</label>
            <input 
              type="password" 
              id="customApiKey"
              className="w-full md:w-1/2 px-3 py-2 bg-slate-700 text-slate-200 border border-slate-600 rounded-md focus:outline-none focus:ring-2 focus:ring-sky-500"
              placeholder="Enter your API key"
            />
          </div>
          <button className="px-4 py-2 bg-sky-600 text-white font-semibold rounded-md hover:bg-sky-700 focus:outline-none focus:ring-2 focus:ring-sky-500">
            Save Key
          </button>
        </div>
      </div>
    </div>
  );
};

export default SettingsPage;

