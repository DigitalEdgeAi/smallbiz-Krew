import React from 'react';

const DashboardPage: React.FC = () => {
  return (
    <div className="p-6 bg-slate-900 min-h-screen text-white">
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-sky-400">Dashboard</h1>
      </header>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div className="bg-slate-800 p-6 rounded-lg shadow">
          <h2 className="text-xl font-semibold text-white mb-2">Welcome!</h2>
          <p className="text-slate-300">This is your SmallBizCrew dashboard. Navigate using the sidebar to access different tools.</p>
        </div>
        <div className="bg-slate-800 p-6 rounded-lg shadow">
          <h2 className="text-xl font-semibold text-white mb-2">Quick Stats (Placeholder)</h2>
          <p className="text-slate-300">Active Projects: 5</p>
          <p className="text-slate-300">Pending Tasks: 12</p>
          <p className="text-slate-300">Unread Messages: 3</p>
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;

