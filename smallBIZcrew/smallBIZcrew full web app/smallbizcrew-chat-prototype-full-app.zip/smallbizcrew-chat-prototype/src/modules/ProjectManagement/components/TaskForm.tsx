import React, { useState } from 'react';

export interface Task {
  id: string;
  title: string;
  description?: string;
  status: 'To Do' | 'In Progress' | 'Done';
  assignee?: string; 
  dueDate?: string;
}

interface TaskFormProps {
  onAddTask: (taskData: Omit<Task, 'id' | 'status'>) => void;
}

const TaskForm: React.FC<TaskFormProps> = ({ onAddTask }) => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [assignee, setAssignee] = useState('');
  const [dueDate, setDueDate] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;
    onAddTask({ 
      title,
      description: description || undefined,
      assignee: assignee || undefined,
      dueDate: dueDate || undefined,
    });
    setTitle('');
    setDescription('');
    setAssignee('');
    setDueDate('');
  };

  return (
    <form onSubmit={handleSubmit} className="mb-6 p-4 bg-slate-800 rounded-lg shadow">
      <h3 className="text-lg font-semibold text-white mb-3">Add New Task</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-3">
        <div>
          <label htmlFor="taskTitle" className="block text-sm font-medium text-slate-300 mb-1">Title</label>
          <input 
            type="text" 
            id="taskTitle"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full px-3 py-2 bg-slate-700 text-slate-200 border border-slate-600 rounded-md focus:outline-none focus:ring-2 focus:ring-sky-500"
            placeholder="Enter task title"
            required
          />
        </div>
        <div>
          <label htmlFor="taskAssignee" className="block text-sm font-medium text-slate-300 mb-1">Assignee (Optional)</label>
          <input 
            type="text" 
            id="taskAssignee"
            value={assignee}
            onChange={(e) => setAssignee(e.target.value)}
            className="w-full px-3 py-2 bg-slate-700 text-slate-200 border border-slate-600 rounded-md focus:outline-none focus:ring-2 focus:ring-sky-500"
            placeholder="Enter assignee name"
          />
        </div>
      </div>
      <div className="mb-3">
        <label htmlFor="taskDescription" className="block text-sm font-medium text-slate-300 mb-1">Description (Optional)</label>
        <textarea 
          id="taskDescription"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          rows={3}
          className="w-full px-3 py-2 bg-slate-700 text-slate-200 border border-slate-600 rounded-md focus:outline-none focus:ring-2 focus:ring-sky-500"
          placeholder="Enter task description"
        />
      </div>
      <div className="mb-4">
        <label htmlFor="taskDueDate" className="block text-sm font-medium text-slate-300 mb-1">Due Date (Optional)</label>
        <input 
          type="date" 
          id="taskDueDate"
          value={dueDate}
          onChange={(e) => setDueDate(e.target.value)}
          className="w-full px-3 py-2 bg-slate-700 text-slate-200 border border-slate-600 rounded-md focus:outline-none focus:ring-2 focus:ring-sky-500"
        />
      </div>
      <button 
        type="submit"
        className="w-full px-4 py-2 bg-sky-600 text-white font-semibold rounded-md hover:bg-sky-700 focus:outline-none focus:ring-2 focus:ring-sky-500"
      >
        Add Task
      </button>
    </form>
  );
};

export default TaskForm;

