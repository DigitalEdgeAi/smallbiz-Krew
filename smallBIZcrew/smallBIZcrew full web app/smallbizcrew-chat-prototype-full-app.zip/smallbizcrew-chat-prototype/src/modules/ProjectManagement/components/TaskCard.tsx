import React from 'react';

export interface Task {
  id: string;
  title: string;
  description?: string;
  status: 'To Do' | 'In Progress' | 'Done';
  assignee?: string; // User ID or name
  dueDate?: string;
}

interface TaskCardProps {
  task: Task;
  onUpdateTaskStatus: (taskId: string, newStatus: Task['status']) => void;
}

const TaskCard: React.FC<TaskCardProps> = ({ task, onUpdateTaskStatus }) => {
  const handleStatusChange = (newStatus: Task['status']) => {
    onUpdateTaskStatus(task.id, newStatus);
  };

  return (
    <div 
      className="bg-slate-700 p-3 rounded-md shadow-md mb-3"
    >
      <h4 className="font-semibold text-sm text-white mb-1">{task.title}</h4>
      {task.description && <p className="text-xs text-slate-300 mb-2 whitespace-pre-wrap">{task.description}</p>}
      <div className="text-xs text-slate-400 mb-2">
        {task.assignee && <p>Assignee: {task.assignee}</p>}
        {task.dueDate && <p>Due: {task.dueDate}</p>}
      </div>
      <div className="mt-2 pt-2 border-t border-slate-600">
        <p className="text-xs text-slate-400 mb-1">Change status:</p>
        <div className="flex space-x-1">
          {(['To Do', 'In Progress', 'Done'] as Task['status'][]).map(statusOption => (
            <button 
              key={statusOption}
              onClick={() => handleStatusChange(statusOption)}
              disabled={task.status === statusOption}
              className={`px-2 py-1 text-xs rounded-md transition-colors 
                ${task.status === statusOption 
                  ? 'bg-sky-500 text-white cursor-default'
                  : 'bg-slate-600 hover:bg-sky-700 text-slate-200 disabled:opacity-50 disabled:cursor-not-allowed'}
              `}
            >
              {statusOption}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default TaskCard;

