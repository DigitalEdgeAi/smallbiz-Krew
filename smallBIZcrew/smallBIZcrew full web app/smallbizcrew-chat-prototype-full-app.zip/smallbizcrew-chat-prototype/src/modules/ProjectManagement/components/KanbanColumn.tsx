import React from 'react';
import TaskCard, { Task } from './TaskCard';

interface KanbanColumnProps {
  title: 'To Do' | 'In Progress' | 'Done';
  tasks: Task[];
  // onDragOver: (e: React.DragEvent<HTMLDivElement>) => void;
  // onDrop: (status: Task['status']) => void;
}

const KanbanColumn: React.FC<KanbanColumnProps> = ({ title, tasks /*, onDragOver, onDrop */ }) => {
  return (
    <div 
      className="bg-slate-800 p-4 rounded-lg w-72 flex-shrink-0 h-full"
      // onDragOver={onDragOver}
      // onDrop={() => onDrop(title)}
    >
      <h3 className="text-lg font-semibold text-white mb-4 capitalize">{title}</h3>
      <div className="space-y-3 h-[calc(100%-40px)] overflow-y-auto">
        {tasks.map(task => (
          <TaskCard key={task.id} task={task} /* onDragStart={() => {}} */ />
        ))}
        {tasks.length === 0 && <p className="text-slate-400 text-sm">No tasks yet.</p>}
      </div>
    </div>
  );
};

export default KanbanColumn;

