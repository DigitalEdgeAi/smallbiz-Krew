import React, { useState, useCallback } from 'react';
import KanbanColumn from './components/KanbanColumn';
import TaskForm from './components/TaskForm';
import { Task } from './components/TaskCard'; // Assuming Task interface is exported from TaskCard.tsx or a shared types file

// Mock initial tasks
const initialTasks: Task[] = [
  { id: 'task-1', title: 'Design homepage layout', status: 'To Do', description: 'Create mockups for the new homepage.', assignee: 'Designer Dave', dueDate: '2025-06-01' },
  { id: 'task-2', title: 'Develop API for user authentication', status: 'In Progress', assignee: 'Backend Team', dueDate: '2025-06-15' },
  { id: 'task-3', title: 'Write user documentation', status: 'To Do', description: 'Document all features for end-users.', assignee: 'Tech Writer Tina' },
  { id: 'task-4', title: 'Test payment gateway integration', status: 'Done', assignee: 'QA Team', description: 'Ensure payments are processed correctly.', dueDate: '2025-05-20' },
  { id: 'task-5', title: 'Setup staging server', status: 'In Progress', assignee: 'Ops Team', dueDate: '2025-06-10' },
];

const ProjectManagementPage: React.FC = () => {
  const [tasks, setTasks] = useState<Task[]>(initialTasks);
  // const [draggedTask, setDraggedTask] = useState<string | null>(null); // For drag and drop

  const handleAddTask = useCallback((taskData: Omit<Task, 'id' | 'status'>) => {
    const newTask: Task = {
      id: `task-${Date.now()}`,
      ...taskData,
      status: 'To Do', // New tasks default to 'To Do'
    };
    setTasks(prevTasks => [...prevTasks, newTask]);
  }, []);

  // Placeholder for updating task status (e.g., via drag and drop or a modal)
  const updateTaskStatus = (taskId: string, newStatus: Task['status']) => {
    setTasks(prevTasks => 
      prevTasks.map(task => 
        task.id === taskId ? { ...task, status: newStatus } : task
      )
    );
    // In a real app, this would also update the backend.
  };

  // Drag and Drop handlers (simplified, would need more robust implementation)
  // const handleDragStart = (taskId: string) => {
  //   setDraggedTask(taskId);
  // };

  // const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
  //   e.preventDefault(); 
  // };

  // const handleDrop = (newStatus: Task['status']) => {
  //   if (draggedTask) {
  //     updateTaskStatus(draggedTask, newStatus);
  //     setDraggedTask(null);
  //   }
  // };

  const todoTasks = tasks.filter(task => task.status === 'To Do');
  const inProgressTasks = tasks.filter(task => task.status === 'In Progress');
  const doneTasks = tasks.filter(task => task.status === 'Done');

  return (
    <div className="p-4 md:p-6 bg-slate-900 min-h-screen text-white flex flex-col">
      <header className="mb-6 md:mb-8">
        <h1 className="text-2xl md:text-3xl font-bold text-sky-400">Project Management Board</h1>
      </header>
      
      <TaskForm onAddTask={handleAddTask} />

      <div className="flex flex-col md:flex-row md:space-x-4 flex-grow overflow-x-auto pb-4">
        <KanbanColumn 
          title="To Do" 
          tasks={todoTasks} 
          // onDragOver={handleDragOver} 
          // onDrop={handleDrop} 
        />
        <KanbanColumn 
          title="In Progress" 
          tasks={inProgressTasks} 
          // onDragOver={handleDragOver} 
          // onDrop={handleDrop} 
        />
        <KanbanColumn 
          title="Done" 
          tasks={doneTasks} 
          // onDragOver={handleDragOver} 
          // onDrop={handleDrop} 
        />
      </div>
    </div>
  );
};

export default ProjectManagementPage;

