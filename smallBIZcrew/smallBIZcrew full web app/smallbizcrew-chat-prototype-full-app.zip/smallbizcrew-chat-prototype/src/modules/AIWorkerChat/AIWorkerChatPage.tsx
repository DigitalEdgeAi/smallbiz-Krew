import React, { useState, useCallback } from "react";
import AIChatInterface, { Message } from "./components/AIChatInterface";
import AIWorkerSelector, { AIWorker } from "./components/AIWorkerSelector";

// Mock data for AI Workers - this should ideally come from a config or backend
const mockWorkers: AIWorker[] = [
  {
    id: "worker-1",
    name: "Marketing Assistant (Echo)",
    description: "Helps with marketing tasks (local echo).",
    modelType: "local_echo",
  },
  {
    id: "worker-2",
    name: "Support Bot (Echo)",
    description: "Provides customer support (local echo).",
    modelType: "local_echo",
  },
  {
    id: "worker-3",
    name: "My Custom API Worker",
    description: "Connects to a user-defined API.",
    modelType: "custom_api",
    apiEndpoint: "https://postman-echo.com/post",
    apiKey: "", // No API key needed for Postman Echo post endpoint
  },
];

// In-memory store for chat histories (workerId -> messages[])
// This would be replaced by backend storage in a real application
const chatHistories: Record<string, Message[]> = {};

const AIWorkerChatPage: React.FC = () => {
  const [selectedWorkerId, setSelectedWorkerId] = useState<string | null>(mockWorkers[0]?.id || null);

  const handleSelectWorker = (workerId: string) => {
    setSelectedWorkerId(workerId);
  };

  const getChatHistoryForWorker = useCallback((workerId: string): Message[] => {
    return chatHistories[workerId] || [];
  }, []);

  const saveMessageToWorkerHistory = useCallback((workerId: string, message: Message) => {
    if (!chatHistories[workerId]) {
      chatHistories[workerId] = [];
    }
    chatHistories[workerId].push(message);
    // In a real app, this might trigger a re-render or save to persistent storage here
  }, []);

  const currentSelectedWorker = mockWorkers.find(w => w.id === selectedWorkerId) || null;

  return (
    <div className="flex h-full bg-slate-900 text-white overflow-hidden">
      <AIWorkerSelector 
        workers={mockWorkers} 
        selectedWorkerId={selectedWorkerId}
        onSelectWorker={handleSelectWorker} 
      />
      <main className="flex-grow pl-64"> {/* pl-64 matches AIWorkerSelector width */}
        <AIChatInterface 
          currentWorker={currentSelectedWorker}
          getChatHistory={getChatHistoryForWorker}
          saveMessageToHistory={saveMessageToWorkerHistory}
        />
      </main>
    </div>
  );
};

export default AIWorkerChatPage;

