import React, { useState } from 'react';

export interface PostData {
  content: string;
  platform: 'Facebook' | 'Twitter' | 'Instagram' | 'LinkedIn'; // Example platforms
  scheduledAt: string; // ISO date string
}

interface PostSchedulerFormProps {
  onSchedulePost: (postData: PostData) => void;
  defaultDate?: Date;
}

const PostSchedulerForm: React.FC<PostSchedulerFormProps> = ({ onSchedulePost, defaultDate }) => {
  const [content, setContent] = useState('');
  const [platform, setPlatform] = useState<PostData['platform']>('Facebook');
  const [scheduledAtDate, setScheduledAtDate] = useState(defaultDate ? defaultDate.toISOString().split('T')[0] : new Date().toISOString().split('T')[0]);
  const [scheduledAtTime, setScheduledAtTime] = useState('10:00');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim() || !scheduledAtDate || !scheduledAtTime) return;
    
    const scheduledDateTime = new Date(`${scheduledAtDate}T${scheduledAtTime}:00`);
    
    onSchedulePost({
      content,
      platform,
      scheduledAt: scheduledDateTime.toISOString(),
    });
    setContent('');
    // Optionally reset date/time or keep them for next post
  };

  return (
    <form onSubmit={handleSubmit} className="p-4 bg-slate-800 rounded-lg shadow mb-6">
      <h3 className="text-xl font-semibold text-white mb-4">Schedule New Post</h3>
      <div className="mb-3">
        <label htmlFor="postContent" className="block text-sm font-medium text-slate-300 mb-1">Content</label>
        <textarea 
          id="postContent"
          value={content}
          onChange={(e) => setContent(e.target.value)}
          rows={4}
          className="w-full px-3 py-2 bg-slate-700 text-slate-200 border border-slate-600 rounded-md focus:outline-none focus:ring-2 focus:ring-sky-500"
          placeholder="What do you want to share?"
          required
        />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-3">
        <div>
          <label htmlFor="postPlatform" className="block text-sm font-medium text-slate-300 mb-1">Platform</label>
          <select 
            id="postPlatform"
            value={platform}
            onChange={(e) => setPlatform(e.target.value as PostData['platform'])}
            className="w-full px-3 py-2 bg-slate-700 text-slate-200 border border-slate-600 rounded-md focus:outline-none focus:ring-2 focus:ring-sky-500"
          >
            <option value="Facebook">Facebook</option>
            <option value="Twitter">Twitter</option>
            <option value="Instagram">Instagram</option>
            <option value="LinkedIn">LinkedIn</option>
          </select>
        </div>
        <div>
          <label htmlFor="postDate" className="block text-sm font-medium text-slate-300 mb-1">Date</label>
          <input 
            type="date"
            id="postDate"
            value={scheduledAtDate}
            onChange={(e) => setScheduledAtDate(e.target.value)}
            className="w-full px-3 py-2 bg-slate-700 text-slate-200 border border-slate-600 rounded-md focus:outline-none focus:ring-2 focus:ring-sky-500"
            required
          />
        </div>
        <div>
          <label htmlFor="postTime" className="block text-sm font-medium text-slate-300 mb-1">Time</label>
          <input 
            type="time"
            id="postTime"
            value={scheduledAtTime}
            onChange={(e) => setScheduledAtTime(e.target.value)}
            className="w-full px-3 py-2 bg-slate-700 text-slate-200 border border-slate-600 rounded-md focus:outline-none focus:ring-2 focus:ring-sky-500"
            required
          />
        </div>
      </div>
      <button 
        type="submit"
        className="w-full px-4 py-2 mt-2 bg-sky-600 text-white font-semibold rounded-md hover:bg-sky-700 focus:outline-none focus:ring-2 focus:ring-sky-500"
      >
        Schedule Post
      </button>
    </form>
  );
};

export default PostSchedulerForm;

