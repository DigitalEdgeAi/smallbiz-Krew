import React from 'react';

// This is a very basic placeholder. A real calendar would use a library like react-big-calendar or build custom grid logic.
interface ScheduledPost {
  id: string;
  title: string;
  date: Date;
  platform: string;
}

interface ContentCalendarProps {
  posts: ScheduledPost[];
  onSelectDate?: (date: Date) => void;
  onSelectPost?: (postId: string) => void;
}

const ContentCalendar: React.FC<ContentCalendarProps> = ({ posts, onSelectDate, onSelectPost }) => {
  // Group posts by date for display
  const postsByDate: { [key: string]: ScheduledPost[] } = posts.reduce((acc, post) => {
    const dateKey = post.date.toDateString();
    if (!acc[dateKey]) {
      acc[dateKey] = [];
    }
    acc[dateKey].push(post);
    return acc;
  }, {} as { [key: string]: ScheduledPost[] });

  // Get a range of dates to display (e.g., current month - simplified here)
  const displayDates: Date[] = [];
  const today = new Date();
  const startDate = new Date(today.getFullYear(), today.getMonth(), 1);
  for (let i = 0; i < 30; i++) { // Display 30 days for simplicity
    const nextDate = new Date(startDate);
    nextDate.setDate(startDate.getDate() + i);
    displayDates.push(nextDate);
  }

  return (
    <div className="bg-slate-800 p-4 rounded-lg shadow">
      <h3 className="text-xl font-semibold text-white mb-4">Content Calendar</h3>
      <div className="grid grid-cols-7 gap-1 text-center text-xs text-slate-400 mb-2">
        {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => <div key={day}>{day}</div>)}
      </div>
      <div className="grid grid-cols-7 gap-1">
        {/* Placeholder for empty days at the start of the month */}
        {Array.from({ length: startDate.getDay() }).map((_, i) => (
          <div key={`empty-${i}`} className="h-24 border border-slate-700"></div>
        ))}
        {displayDates.map(date => {
          const dateKey = date.toDateString();
          const dailyPosts = postsByDate[dateKey] || [];
          return (
            <div 
              key={dateKey} 
              className="h-24 border border-slate-700 p-1.5 overflow-y-auto hover:bg-slate-700 cursor-pointer transition-colors"
              onClick={() => onSelectDate && onSelectDate(date)}
            >
              <span className={`text-xs ${date.toDateString() === today.toDateString() ? 'text-sky-400 font-bold' : 'text-slate-300'}`}>{date.getDate()}</span>
              <div className="mt-1 space-y-1">
                {dailyPosts.map(post => (
                  <div 
                    key={post.id} 
                    className="bg-sky-600 text-white text-xs p-1 rounded-sm truncate hover:bg-sky-500"
                    onClick={(e) => { e.stopPropagation(); onSelectPost && onSelectPost(post.id); }}
                  >
                    {post.title}
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default ContentCalendar;

