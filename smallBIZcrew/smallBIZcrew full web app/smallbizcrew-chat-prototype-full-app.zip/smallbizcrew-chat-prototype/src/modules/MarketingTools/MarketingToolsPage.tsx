import React, { useState, useCallback } from "react";
import ContentCalendar from "./components/ContentCalendar";
import PostSchedulerForm, { PostData } from "./components/PostSchedulerForm";

// Define the structure for a scheduled post, including an ID
export interface ScheduledPost extends PostData {
  id: string;
  title: string; // For display in calendar, derived from content or user input
}

// Mock initial scheduled posts
const initialScheduledPosts: ScheduledPost[] = [
  {
    id: "post-1",
    title: "New Blog Post Live!",
    content: "Check out our latest blog post on productivity hacks!",
    platform: "Facebook",
    scheduledAt: new Date(new Date().setDate(new Date().getDate() + 2)).toISOString(), // 2 days from now
    date: new Date(new Date().setDate(new Date().getDate() + 2)) // For calendar component
  },
  {
    id: "post-2",
    title: "Weekend Sale Teaser",
    content: "Big weekend sale coming up! Don\'t miss out.",
    platform: "Twitter",
    scheduledAt: new Date(new Date().setDate(new Date().getDate() + 4)).toISOString(), // 4 days from now
    date: new Date(new Date().setDate(new Date().getDate() + 4))
  },
  {
    id: "post-3",
    title: "Feature Update Video",
    content: "We\'ve just released a new feature! Watch the video to learn more.",
    platform: "LinkedIn",
    scheduledAt: new Date(new Date().setDate(new Date().getDate() - 1)).toISOString(), // Yesterday
    date: new Date(new Date().setDate(new Date().getDate() - 1))
  },
];

const MarketingToolsPage: React.FC = () => {
  const [scheduledPosts, setScheduledPosts] = useState<ScheduledPost[]>(initialScheduledPosts);
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [selectedPostId, setSelectedPostId] = useState<string | null>(null);

  const handleSchedulePost = useCallback((postData: PostData) => {
    const newPost: ScheduledPost = {
      ...postData,
      id: `post-${Date.now()}`,
      title: postData.content.substring(0, 30) + "...", // Simple title generation
      date: new Date(postData.scheduledAt), // Ensure date object for calendar
    };
    setScheduledPosts((prevPosts) => [...prevPosts, newPost].sort((a,b) => new Date(a.scheduledAt).getTime() - new Date(b.scheduledAt).getTime()));
    console.log("Scheduled new post:", newPost);
  }, []);

  const handleSelectDate = (date: Date) => {
    setSelectedDate(date);
    setSelectedPostId(null); // Clear selected post when a date is clicked
    console.log("Selected date:", date.toDateString());
  };

  const handleSelectPost = (postId: string) => {
    setSelectedPostId(postId);
    setSelectedDate(null); // Clear selected date when a post is clicked
    console.log("Selected post ID:", postId);
  };

  const postToDisplayDetails = scheduledPosts.find(p => p.id === selectedPostId);

  return (
    <div className="p-4 md:p-6 bg-slate-900 min-h-screen text-white flex flex-col">
      <header className="mb-6 md:mb-8">
        <h1 className="text-2xl md:text-3xl font-bold text-sky-400">Marketing Tools</h1>
      </header>

      <div className="flex flex-col lg:flex-row gap-6">
        <div className="lg:w-2/3">
          <ContentCalendar 
            posts={scheduledPosts} 
            onSelectDate={handleSelectDate}
            onSelectPost={handleSelectPost}
          />
        </div>
        <div className="lg:w-1/3">
          <PostSchedulerForm onSchedulePost={handleSchedulePost} defaultDate={selectedDate || undefined} />
          {selectedPostId && postToDisplayDetails && (
            <div className="mt-6 p-4 bg-slate-800 rounded-lg shadow">
              <h4 className="text-lg font-semibold text-white mb-2">Post Details: {postToDisplayDetails.title}</h4>
              <p className="text-sm text-slate-300 mb-1"><span className="font-semibold">Platform:</span> {postToDisplayDetails.platform}</p>
              <p className="text-sm text-slate-300 mb-1"><span className="font-semibold">Scheduled:</span> {new Date(postToDisplayDetails.scheduledAt).toLocaleString()}</p>
              <p className="text-sm text-slate-300 whitespace-pre-wrap"><span className="font-semibold">Content:</span> {postToDisplayDetails.content}</p>
              {/* Add edit/delete buttons here in a future iteration */}
            </div>
          )}
          {selectedDate && !selectedPostId && (
             <div className="mt-6 p-4 bg-slate-800 rounded-lg shadow">
              <h4 className="text-lg font-semibold text-white mb-2">Selected Date: {selectedDate.toLocaleDateString()}</h4>
              <p className="text-sm text-slate-300">You can schedule a new post for this date using the form above.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default MarketingToolsPage;

