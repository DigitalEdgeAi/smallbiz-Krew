import React, { useState } from "react";

interface ChatInputProps {
  onSendMessage: (messageText: string) => void;
  onSendFile: (file: File) => void; 
}

const ChatInput: React.FC<ChatInputProps> = ({ onSendMessage, onSendFile }) => {
  const [text, setText] = useState("");

  const handleSendText = (e: React.FormEvent) => {
    e.preventDefault();
    if (text.trim()) {
      onSendMessage(text);
      setText("");
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      onSendFile(e.target.files[0]);
      // Reset file input to allow selecting the same file again if needed
      e.target.value = ""; 
    }
  };

  return (
    <form onSubmit={handleSendText} className="p-4 border-t border-slate-700 bg-slate-800">
      <div className="flex items-center space-x-2">
        <label htmlFor="file-upload" className="cursor-pointer p-2 rounded-md hover:bg-slate-700">
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6 text-slate-400">
            <path strokeLinecap="round" strokeLinejoin="round" d="m18.375 12.739-7.693 7.693a4.5 4.5 0 0 1-6.364-6.364l10.94-10.94A3.375 3.375 0 0 1 19.5 7.372l-10.94 10.94a2.25 2.25 0 0 1-3.182-3.182l7.693-7.693a.75.75 0 0 1 1.06 1.06l-7.693 7.693a1.125 1.125 0 0 0 1.591 1.591l10.94-10.94A2.25 2.25 0 0 0 15.75 5.25l-10.94 10.94a3.375 3.375 0 0 0 4.773 4.773l7.693-7.693a.75.75 0 0 1 1.06-1.06Z" />
          </svg>
          <input id="file-upload" type="file" className="hidden" onChange={handleFileChange} />
        </label>
        <input 
          type="text"
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Type a message..."
          className="flex-grow px-3 py-2 bg-slate-700 text-slate-200 border border-slate-600 rounded-md focus:outline-none focus:ring-2 focus:ring-sky-500"
        />
        <button 
          type="submit"
          className="px-4 py-2 bg-sky-600 text-white font-semibold rounded-md hover:bg-sky-700 focus:outline-none focus:ring-2 focus:ring-sky-500"
        >
          Send
        </button>
      </div>
    </form>
  );
};

export default ChatInput;

