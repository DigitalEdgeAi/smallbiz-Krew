import React from 'react';

export interface TeamMessage {
  id: string;
  senderName: string;
  senderId: string;
  text: string;
  timestamp: Date;
  isOwnMessage: boolean;
  avatar?: string;
}

interface ChatMessageProps {
  message: TeamMessage;
}

const ChatMessage: React.FC<ChatMessageProps> = ({ message }) => {
  return (
    <div className={`flex items-start space-x-3 py-2 ${message.isOwnMessage ? 'justify-end' : ''}`}>
      {!message.isOwnMessage && (
        <img 
          src={message.avatar || `https://ui-avatars.com/api/?name=${message.senderName.replace(' ', '+')}&background=random`}
          alt={message.senderName}
          className="w-8 h-8 rounded-full"
        />
      )}
      <div 
        className={`max-w-xs md:max-w-md px-4 py-2 rounded-lg shadow 
          ${message.isOwnMessage 
            ? 'bg-sky-600 text-white'
            : 'bg-slate-700 text-slate-200'}
        `}
      >
        {!message.isOwnMessage && <p className="text-xs font-semibold mb-0.5 text-sky-400">{message.senderName}</p>}
        <p className="text-sm whitespace-pre-wrap">{message.text}</p>
        <p className={`text-xs mt-1 ${message.isOwnMessage ? 'text-sky-200' : 'text-slate-400'} text-right`}>
          {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </p>
      </div>
      {message.isOwnMessage && (
        <img 
          src={message.avatar || `https://ui-avatars.com/api/?name=${message.senderName.replace(' ', '+')}&background=random`}
          alt={message.senderName}
          className="w-8 h-8 rounded-full ml-3"
        />
      )}
    </div>
  );
};

export default ChatMessage;

