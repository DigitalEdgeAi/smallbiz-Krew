import React, { useState, useCallback, useEffect, useRef } from "react";
import ChatMessage, { TeamMessage } from "./components/ChatMessage";
import ChatInput from "./components/ChatInput";

// Mock data for channels and users
interface Channel {
  id: string;
  name: string;
}

const mockChannels: Channel[] = [
  { id: "channel-1", name: "General" },
  { id: "channel-2", name: "Marketing Team" },
  { id: "channel-3", name: "Project Alpha" },
];

// Mock current user (would come from auth in a real app)
const currentUserId = "user-self";
const currentUserName = "Me";
const currentUserAvatar = "https://ui-avatars.com/api/?name=Me&background=0D8ABC&color=fff";

const TeamChatPage: React.FC = () => {
  const [messages, setMessages] = useState<TeamMessage[]>([]);
  const [activeChannel, setActiveChannel] = useState<Channel>(mockChannels[0]);
  const messagesEndRef = useRef<null | HTMLDivElement>(null);

  // Simulate loading messages for the active channel
  useEffect(() => {
    console.log(`Loading messages for ${activeChannel.name}`);
    const initialMessages: TeamMessage[] = [
      {
        id: "msg-1",
        senderName: "Alice Wonderland",
        senderId: "user-alice",
        text: "Hello team! How is everyone doing today?",
        timestamp: new Date(Date.now() - 1000 * 60 * 5), // 5 minutes ago
        isOwnMessage: false,
        avatar: "https://ui-avatars.com/api/?name=Alice+Wonderland&background=random",
      },
      {
        id: "msg-2",
        senderName: "Bob The Builder",
        senderId: "user-bob",
        text: "Doing great, Alice! Just wrapping up the Q2 report.",
        timestamp: new Date(Date.now() - 1000 * 60 * 3), // 3 minutes ago
        isOwnMessage: false,
        avatar: "https://ui-avatars.com/api/?name=Bob+Builder&background=random",
      },
      {
        id: "msg-3",
        senderName: currentUserName,
        senderId: currentUserId,
        text: "Hi Alice and Bob! I am working on the new feature integration.",
        timestamp: new Date(Date.now() - 1000 * 60 * 1), // 1 minute ago
        isOwnMessage: true,
        avatar: currentUserAvatar,
      },
    ];
    setMessages(initialMessages);
  }, [activeChannel]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(scrollToBottom, [messages]);

  const handleSendMessage = useCallback((messageText: string) => {
    const newMessage: TeamMessage = {
      id: `msg-${Date.now()}`,
      senderName: currentUserName,
      senderId: currentUserId,
      text: messageText,
      timestamp: new Date(),
      isOwnMessage: true,
      avatar: currentUserAvatar,
    };
    setMessages((prevMessages) => [...prevMessages, newMessage]);

    // Simulate another user responding after a short delay
    setTimeout(() => {
      const botResponse: TeamMessage = {
        id: `msg-${Date.now() + 1}`,
        senderName: "Charlie Brown",
        senderId: "user-charlie",
        text: `Got it, ${currentUserName}! Thanks for the update on \"${messageText.substring(0,20)}...\"`,
        timestamp: new Date(),
        isOwnMessage: false,
        avatar: "https://ui-avatars.com/api/?name=Charlie+Brown&background=random",
      };
      setMessages((prevMessages) => [...prevMessages, botResponse]);
    }, 1500);
  }, []);

  const handleSendFile = useCallback((file: File) => {
    const fileMessage: TeamMessage = {
      id: `file-${Date.now()}`,
      senderName: currentUserName,
      senderId: currentUserId,
      text: `File shared: ${file.name} (${(file.size / 1024).toFixed(2)} KB)`,
      timestamp: new Date(),
      isOwnMessage: true,
      avatar: currentUserAvatar,
      // Potentially add a fileType or fileUrl property here in a real app
    };
    setMessages((prevMessages) => [...prevMessages, fileMessage]);
    // In a real app, you would upload the file here and then update the message with a URL or confirmation.
    console.log("File to send:", file.name, file.size);

    // Simulate another user acknowledging the file
    setTimeout(() => {
      const botResponse: TeamMessage = {
        id: `msg-${Date.now() + 1}`,
        senderName: "Charlie Brown",
        senderId: "user-charlie",
        text: `Received file: ${file.name}`,
        timestamp: new Date(),
        isOwnMessage: false,
        avatar: "https://ui-avatars.com/api/?name=Charlie+Brown&background=random",
      };
      setMessages((prevMessages) => [...prevMessages, botResponse]);
    }, 1500);
  }, []);

  return (
    <div className="flex h-screen bg-slate-900 text-white">
      {/* Channel List Sidebar */}
      <div className="w-64 bg-slate-800 p-4 border-r border-slate-700 flex-shrink-0">
        <h2 className="text-xl font-semibold mb-4 text-sky-400">Channels</h2>
        <ul className="space-y-2">
          {mockChannels.map((channel) => (
            <li key={channel.id}>
              <button
                onClick={() => setActiveChannel(channel)}
                className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors duration-150
                  ${activeChannel.id === channel.id
                    ? "bg-sky-600 text-white font-semibold"
                    : "hover:bg-slate-700 text-slate-300"}
                `}
              >
                # {channel.name}
              </button>
            </li>
          ))}
        </ul>
      </div>

      {/* Main Chat Area */}
      <div className="flex-grow flex flex-col">
        {/* Chat Header */}
        <header className="p-4 border-b border-slate-700 bg-slate-800">
          <h2 className="text-xl font-semibold"># {activeChannel.name}</h2>
        </header>

        {/* Message List */}
        <div className="flex-grow p-4 space-y-2 overflow-y-auto bg-slate-900">
          {messages.map((msg) => (
            <ChatMessage key={msg.id} message={msg} />
          ))}
          <div ref={messagesEndRef} />
        </div>

        {/* Chat Input */}
        <ChatInput onSendMessage={handleSendMessage} onSendFile={handleSendFile} />
      </div>
    </div>
  );
};

export default TeamChatPage;

