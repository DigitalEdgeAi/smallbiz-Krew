import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import SidebarNav from './components/SidebarNav';
import DashboardPage from './pages/DashboardPage';
import SettingsPage from './pages/SettingsPage';
import ProjectManagementPage from './modules/ProjectManagement/ProjectManagementPage';
import TeamChatPage from './modules/TeamChat/TeamChatPage';
import MarketingToolsPage from './modules/MarketingTools/MarketingToolsPage';
import AIWorkerChatPage from './modules/AIWorkerChat/AIWorkerChatPage';

// Placeholder for a simple 404 page
const NotFoundPage: React.FC = () => (
  <div className="p-6 bg-slate-900 min-h-screen text-white flex justify-center items-center">
    <h1 className="text-4xl font-bold text-sky-400">404 - Page Not Found</h1>
  </div>
);

function App() {
  return (
    <Router>
      <div className="flex h-screen bg-slate-900">
        <SidebarNav />
        <main className="flex-grow ml-64 overflow-y-auto"> {/* ml-64 matches SidebarNav width */}
          <Routes>
            <Route path="/" element={<DashboardPage />} />
            <Route path="/projects" element={<ProjectManagementPage />} />
            <Route path="/team-chat" element={<TeamChatPage />} />
            <Route path="/marketing" element={<MarketingToolsPage />} />
            <Route path="/ai-workers" element={<AIWorkerChatPage />} />
            <Route path="/settings" element={<SettingsPage />} />
            <Route path="/index.html" element={<Navigate to="/" replace />} /> {/* Handle index.html redirect */}
            <Route path="*" element={<NotFoundPage />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;

