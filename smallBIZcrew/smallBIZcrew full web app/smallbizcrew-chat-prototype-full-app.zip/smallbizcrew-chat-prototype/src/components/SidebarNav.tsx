import React from 'react';
import { NavLink } from 'react-router-dom';
import { Home, Briefcase, MessageSquare, Calendar, Cpu, Settings } from 'lucide-react'; // Using lucide-react icons as per template

interface NavItem {
  to: string;
  label: string;
  icon: React.ElementType;
}

const navItems: NavItem[] = [
  { to: '/', label: 'Dashboard', icon: Home },
  { to: '/projects', label: 'Projects', icon: Briefcase },
  { to: '/team-chat', label: 'Team Chat', icon: MessageSquare },
  { to: '/marketing', label: 'Marketing', icon: Calendar },
  { to: '/ai-workers', label: 'AI Workers', icon: Cpu },
  { to: '/settings', label: 'Settings', icon: Settings }, // Placeholder for settings
];

const SidebarNav: React.FC = () => {
  return (
    <aside className="w-64 bg-slate-800 text-white p-4 fixed top-0 left-0 h-full flex flex-col border-r border-slate-700">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-sky-400">SmallBizCrew</h1>
      </div>
      <nav className="flex-grow">
        <ul className="space-y-2">
          {navItems.map((item) => (
            <li key={item.to}>
              <NavLink
                to={item.to}
                end // Use 'end' for exact match on root/dashboard route
                className={({ isActive }) =>
                  `flex items-center space-x-3 px-3 py-2.5 rounded-md text-sm font-medium transition-colors duration-150 
                  ${isActive 
                    ? 'bg-sky-600 text-white'
                    : 'text-slate-300 hover:bg-slate-700 hover:text-white'
                  }`
                }
              >
                <item.icon className="w-5 h-5" />
                <span>{item.label}</span>
              </NavLink>
            </li>
          ))}
        </ul>
      </nav>
      <div className="mt-auto pb-4">
        <p className="text-xs text-slate-500 text-center">© 2025 SmallBizCrew</p>
      </div>
    </aside>
  );
};

export default SidebarNav;

