import React, { useState, useEffect, useCallback } from 'react';
import { AIWorker } from './AIWorkerSelector'; // Import AIWorker type

export interface Message {
  id: string;
  text: string;
  sender: 'user' | 'ai';
  timestamp: Date;
}

interface AIChatInterfaceProps {
  currentWorker: AIWorker | null; // Pass the full worker object
  getChatHistory: (workerId: string) => Message[];
  saveMessageToHistory: (workerId: string, message: Message) => void;
}

const AIChatInterface: React.FC<AIChatInterfaceProps> = ({ 
  currentWorker,
  getChatHistory,
  saveMessageToHistory 
}) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (currentWorker) {
      setMessages(getChatHistory(currentWorker.id));
    } else {
      setMessages([]); // Clear messages if no worker is selected
    }
  }, [currentWorker, getChatHistory]);

  const handleSend = useCallback(async () => {
    if (input.trim() === '' || !currentWorker) return;

    const userMessage: Message = {
      id: `user-${Date.now()}`,
      text: input,
      sender: 'user',
      timestamp: new Date(),
    };
    setMessages((prevMessages) => [...prevMessages, userMessage]);
    saveMessageToHistory(currentWorker.id, userMessage);
    const currentInput = input;
    setInput('');
    setIsLoading(true);

    let aiTextResponse = `Response from ${currentWorker.name} (local echo): "${currentInput}"`;

    if (currentWorker.modelType === 'custom_api') {
      if (!currentWorker.apiEndpoint) {
        aiTextResponse = `Error: API endpoint not configured for ${currentWorker.name}.`;
      } else {
        try {
          // Basic example: assumes API expects a JSON with a "prompt" field
          // and returns JSON with a "response" field.
          // User needs to provide API key in headers if required by their API.
          const headers: HeadersInit = {
            'Content-Type': 'application/json',
          };
          if (currentWorker.apiKey) {
            // Common practice is to use a Bearer token or a custom header like X-API-Key
            // This is a generic example, user might need to adjust based on their API
            headers['Authorization'] = `Bearer ${currentWorker.apiKey}`;
            // or headers['X-API-Key'] = currentWorker.apiKey;
          }

          const apiResponse = await fetch(currentWorker.apiEndpoint, {
            method: 'POST',
            headers: headers,
            body: JSON.stringify({ prompt: currentInput }), // Adjust payload as needed
          });

          if (!apiResponse.ok) {
            throw new Error(`API request failed with status ${apiResponse.status}`);
          }

          const responseData = await apiResponse.json();
          // Adjust how to extract text based on actual API response structure
          aiTextResponse = responseData.response || responseData.text || 'AI response received, but could not parse.'; 
        } catch (error) {
          console.error('API call error:', error);
          aiTextResponse = `Error calling API for ${currentWorker.name}: ${error instanceof Error ? error.message : 'Unknown error'}`;
        }
      }
    }

    const aiResponseMessage: Message = {
      id: `ai-${Date.now()}`,
      text: aiTextResponse,
      sender: 'ai',
      timestamp: new Date(),
    };
    setMessages((prevMessages) => [...prevMessages, aiResponseMessage]);
    saveMessageToHistory(currentWorker.id, aiResponseMessage);
    setIsLoading(false);

  }, [input, currentWorker, saveMessageToHistory]);

  if (!currentWorker) {
    return (
      <div className="flex flex-col h-full w-full bg-slate-800 text-white shadow-xl rounded-lg items-center justify-center ml-64">
        <p className="text-xl text-slate-400">Please select an AI worker to start chatting.</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full w-full bg-slate-800 text-white shadow-xl rounded-lg ml-64"> {/* Ensure ml-64 if sidebar is fixed */}
      <div className="p-4 border-b border-slate-700">
        <h2 className="text-xl font-semibold">Chat with {currentWorker.name} ({currentWorker.modelType})</h2>
      </div>
      <div className="flex-grow p-4 space-y-4 overflow-y-auto">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${msg.sender === 'user' ? 'bg-sky-600 text-white' : 'bg-slate-700 text-slate-200'}`}
            >
              <p className="text-sm whitespace-pre-wrap">{msg.text}</p>
              <p className="text-xs text-slate-400 mt-1 text-right">
                {msg.timestamp.toLocaleTimeString()}
              </p>
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
            <div className="max-w-xs lg:max-w-md px-4 py-2 rounded-lg bg-slate-700 text-slate-200">
              <p className="text-sm italic">AI is thinking...</p>
            </div>
          </div>
        )}
      </div>
      <div className="p-4 border-t border-slate-700">
        <div className="flex items-center">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && !isLoading && handleSend()}
            placeholder="Type your message..."
            disabled={isLoading}
            className="flex-grow px-3 py-2 bg-slate-700 text-slate-200 border border-slate-600 rounded-l-md focus:outline-none focus:ring-2 focus:ring-sky-500 disabled:opacity-50"
          />
          <button
            onClick={handleSend}
            disabled={isLoading}
            className="px-4 py-2 bg-sky-600 text-white font-semibold rounded-r-md hover:bg-sky-700 focus:outline-none focus:ring-2 focus:ring-sky-500 disabled:opacity-50"
          >
            {isLoading ? 'Sending...' : 'Send'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default AIChatInterface;

